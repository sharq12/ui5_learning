sap.ui.define([], function(){

    "use strict";
    return {
        classText: function(sClass){
            switch (sClass){
                case "C":
                    return "Bussiness Class";
                case "Y":
                    return "Economy Class";
                case "F":
                    return "First Class";
                default:
                    return sClass;
            }
        },

        cancelStatus: function(status){
            switch(status){
                case "X":
                    return "Cancelled";
                case "":
                    return "Booked";
                default:
                    return status;
            }
        }
    }
})